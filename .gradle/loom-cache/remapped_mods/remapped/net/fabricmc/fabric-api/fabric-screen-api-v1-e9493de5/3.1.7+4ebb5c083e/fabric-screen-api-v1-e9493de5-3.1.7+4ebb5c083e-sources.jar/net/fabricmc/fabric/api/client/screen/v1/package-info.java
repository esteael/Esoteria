/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Fabric Screen API v1.
 *
 * <p>The screen api provides events and utilities in this package are related to the lifecycle of a {@link net.minecraft.client.gui.screens.Screen}.
 *
 * <p>For general screen events see {@link net.fabricmc.fabric.api.client.screen.v1.ScreenEvents}.
 *
 * <p>For screen events related to the use of a mouse, see {@link net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents}.
 *
 * <p>For screen events related to the use of a keyboard, see {@link net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents}.
 *
 * @see net.fabricmc.fabric.api.client.screen.v1.Screens
 */
@NullMarked
package net.fabricmc.fabric.api.client.screen.v1;

import org.jspecify.annotations.NullMarked;
